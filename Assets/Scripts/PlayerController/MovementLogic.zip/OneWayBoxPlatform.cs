using UnityEngine;

[DisallowMultipleComponent]
[RequireComponent(typeof(BoxCollider))]
public sealed class OneWayBoxPlatform : MonoBehaviour
{
    [Header("One Way")]
    [Tooltip("Если низ капсулы героя ниже этой линии, герой может пройти платформу снизу вверх.")]
    [SerializeField] private float passThroughMargin = 0.05f;

    [Tooltip("Если низ капсулы героя поднялся выше этой линии и герой уже не летит вверх быстро, коллизия снова включается.")]
    [SerializeField] private float solidifyMargin = 0.03f;

    [Header("Horizontal Check")]
    [Tooltip("Небольшое расширение по X для проверки, находится ли герой над/под верхней площадью платформы.")]
    [SerializeField] private float horizontalPaddingX = 0.02f;

    [Tooltip("Небольшое расширение по Z для проверки, находится ли герой над/под верхней площадью платформы.")]
    [SerializeField] private float horizontalPaddingZ = 0.02f;

    [Header("Debug")]
    [SerializeField] private bool drawDebugGizmos = true;
    [SerializeField] private float debugLineHalfWidth = 0.75f;

    private BoxCollider box;

    public BoxCollider Box => box != null ? box : (box = GetComponent<BoxCollider>());
    public Bounds WorldBounds => Box.bounds;
    public float TopY => WorldBounds.max.y;
    public float PassThroughThresholdY => TopY - passThroughMargin;
    public float SolidifyThresholdY => TopY + solidifyMargin;
    public float HorizontalPaddingX => horizontalPaddingX;
    public float HorizontalPaddingZ => horizontalPaddingZ;

    private void Awake()
    {
        CacheComponents();
        EnsureNonTriggerCollider();
    }

    private void Reset()
    {
        CacheComponents();
        ClampSettings();
        EnsureNonTriggerCollider();
    }

    private void OnValidate()
    {
        ClampSettings();
        CacheComponents();

        if (!Application.isPlaying)
            EnsureNonTriggerCollider();
    }

    public bool HasHorizontalSupportOverlap(Bounds actorBounds)
    {
        Bounds platformBounds = WorldBounds;

        float platformMinX = platformBounds.min.x - horizontalPaddingX;
        float platformMaxX = platformBounds.max.x + horizontalPaddingX;
        float platformMinZ = platformBounds.min.z - horizontalPaddingZ;
        float platformMaxZ = platformBounds.max.z + horizontalPaddingZ;

        bool overlapX = actorBounds.max.x >= platformMinX && actorBounds.min.x <= platformMaxX;
        bool overlapZ = actorBounds.max.z >= platformMinZ && actorBounds.min.z <= platformMaxZ;

        return overlapX && overlapZ;
    }

    private void CacheComponents()
    {
        if (box == null)
            box = GetComponent<BoxCollider>();
    }

    private void ClampSettings()
    {
        passThroughMargin = Mathf.Max(0f, passThroughMargin);
        solidifyMargin = Mathf.Max(0f, solidifyMargin);
        horizontalPaddingX = Mathf.Max(0f, horizontalPaddingX);
        horizontalPaddingZ = Mathf.Max(0f, horizontalPaddingZ);
        debugLineHalfWidth = Mathf.Max(0.05f, debugLineHalfWidth);
    }

    private void EnsureNonTriggerCollider()
    {
        if (box != null)
            box.isTrigger = false;
    }

    private void OnDrawGizmosSelected()
    {
        if (!drawDebugGizmos)
            return;

        CacheComponents();
        if (box == null)
            return;

        Bounds b = box.bounds;
        float halfWidth = Mathf.Max(debugLineHalfWidth, b.extents.x);
        float z = b.center.z;

        Vector3 topA = new Vector3(b.center.x - halfWidth, TopY, z);
        Vector3 topB = new Vector3(b.center.x + halfWidth, TopY, z);

        Vector3 passA = new Vector3(b.center.x - halfWidth, PassThroughThresholdY, z);
        Vector3 passB = new Vector3(b.center.x + halfWidth, PassThroughThresholdY, z);

        Vector3 solidA = new Vector3(b.center.x - halfWidth, SolidifyThresholdY, z);
        Vector3 solidB = new Vector3(b.center.x + halfWidth, SolidifyThresholdY, z);

        Gizmos.color = new Color(0.1f, 1f, 0.2f, 1f);
        Gizmos.DrawWireCube(b.center, b.size);

        Gizmos.color = Color.green;
        Gizmos.DrawLine(topA, topB);

        Gizmos.color = new Color(1f, 0.75f, 0f, 1f);
        Gizmos.DrawLine(passA, passB);

        Gizmos.color = Color.cyan;
        Gizmos.DrawLine(solidA, solidB);
    }
}
