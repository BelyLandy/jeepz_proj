using System.Collections.Generic;
using UnityEngine;

[DisallowMultipleComponent]
[RequireComponent(typeof(Rigidbody), typeof(CapsuleCollider))]
public sealed class OneWayPlatformResolver : MonoBehaviour
{
    [Header("Search")]
    [Tooltip("Слой, на котором лежат one-way платформы.")]
    [SerializeField] private LayerMask oneWayPlatformMask;

    [Tooltip("Насколько расширять поиск платформ по X вокруг героя.")]
    [SerializeField] private float searchPaddingX = 0.2f;

    [Tooltip("Насколько расширять поиск платформ по Y вокруг героя.")]
    [SerializeField] private float searchPaddingY = 0.6f;

    [Tooltip("Насколько расширять поиск платформ по Z вокруг героя.")]
    [SerializeField] private float searchPaddingZ = 0.2f;

    [Tooltip("Если nearby-платформ в буфере оказалось слишком много, будет предупреждение в консоль.")]
    [SerializeField] private bool warnIfHitBufferIsFull = true;

    [Header("Solid / Pass Through")]
    [Tooltip("Пока герой летит вверх быстрее этого значения, коллизия не вернётся даже если герой уже выше верха платформы.")]
    [SerializeField] private float maxUpwardSpeedToSolidify = 0.1f;

    [Tooltip("Небольшой запас для сравнения высот, чтобы убрать дёрганье на границе.")]
    [SerializeField] private float bottomYEpsilon = 0.005f;

    [Header("Debug")]
    [SerializeField] private bool drawDebugPreview = true;
    [SerializeField] private bool drawDebugWhileSelected = true;

    private Rigidbody rb;
    private CapsuleCollider capsule;

    private readonly Collider[] overlapHits = new Collider[32];
    private readonly List<OneWayBoxPlatform> nearbyPlatforms = new List<OneWayBoxPlatform>(16);
    private readonly HashSet<OneWayBoxPlatform> ignoredPlatforms = new HashSet<OneWayBoxPlatform>();
    private readonly List<OneWayBoxPlatform> ignoredBuffer = new List<OneWayBoxPlatform>(16);

    public Rigidbody RigidbodyComponent => rb != null ? rb : (rb = GetComponent<Rigidbody>());
    public CapsuleCollider CapsuleColliderComponent => capsule != null ? capsule : (capsule = GetComponent<CapsuleCollider>());

    private void Awake()
    {
        CacheComponents();
        ClampSettings();
    }

    private void OnValidate()
    {
        ClampSettings();
        CacheComponents();
    }

    private void FixedUpdate()
    {
        if (!EnsureRuntimeState())
            return;

        CollectNearbyPlatforms();
        ResolveNearbyPlatforms();
        RestoreReleasedPlatforms();
        DrawRuntimeDebug();
    }

    private void OnDisable()
    {
        RestoreAllIgnoredCollisions();
    }

    private void OnDestroy()
    {
        RestoreAllIgnoredCollisions();
    }

    private bool EnsureRuntimeState()
    {
        CacheComponents();
        return rb != null && capsule != null;
    }

    private void CollectNearbyPlatforms()
    {
        nearbyPlatforms.Clear();

        Bounds playerBounds = capsule.bounds;
        Vector3 center = playerBounds.center;
        Vector3 halfExtents = new Vector3(
            playerBounds.extents.x + searchPaddingX,
            playerBounds.extents.y + searchPaddingY,
            playerBounds.extents.z + searchPaddingZ
        );

        int hitCount = Physics.OverlapBoxNonAlloc(
            center,
            halfExtents,
            overlapHits,
            Quaternion.identity,
            oneWayPlatformMask,
            QueryTriggerInteraction.Ignore
        );

        if (warnIfHitBufferIsFull && hitCount == overlapHits.Length)
        {
            Debug.LogWarning(
                $"[{nameof(OneWayPlatformResolver)}] Nearby platform hit buffer is full on '{name}'. " +
                $"Increase overlap buffer size if some one-way platforms are missed.",
                this);
        }

        for (int i = 0; i < hitCount; i++)
        {
            Collider hit = overlapHits[i];
            if (hit == null)
                continue;

            OneWayBoxPlatform platform = hit.GetComponent<OneWayBoxPlatform>();
            if (platform == null)
                platform = hit.GetComponentInParent<OneWayBoxPlatform>();

            if (platform == null || platform.Box != hit)
                continue;

            if (!nearbyPlatforms.Contains(platform))
                nearbyPlatforms.Add(platform);
        }
    }

    private void ResolveNearbyPlatforms()
    {
        Bounds playerBounds = capsule.bounds;
        float playerBottomY = playerBounds.min.y;
        float verticalSpeed = rb.linearVelocity.y;

        for (int i = 0; i < nearbyPlatforms.Count; i++)
        {
            OneWayBoxPlatform platform = nearbyPlatforms[i];
            if (platform == null)
                continue;

            bool hasHorizontalOverlap = platform.HasHorizontalSupportOverlap(playerBounds);
            if (!hasHorizontalOverlap)
            {
                SetIgnored(platform, false);
                continue;
            }

            if (ShouldIgnorePlatform(platform, playerBottomY))
            {
                SetIgnored(platform, true);
                continue;
            }

            if (ShouldRestorePlatform(platform, playerBottomY, verticalSpeed))
            {
                SetIgnored(platform, false);
            }
        }
    }

    private bool ShouldIgnorePlatform(OneWayBoxPlatform platform, float playerBottomY)
    {
        return playerBottomY < platform.PassThroughThresholdY - bottomYEpsilon;
    }

    private bool ShouldRestorePlatform(OneWayBoxPlatform platform, float playerBottomY, float verticalSpeed)
    {
        return playerBottomY > platform.SolidifyThresholdY + bottomYEpsilon
            && verticalSpeed <= maxUpwardSpeedToSolidify;
    }

    private void RestoreReleasedPlatforms()
    {
        if (ignoredPlatforms.Count == 0)
            return;

        Bounds playerBounds = capsule.bounds;

        ignoredBuffer.Clear();
        ignoredBuffer.AddRange(ignoredPlatforms);

        for (int i = 0; i < ignoredBuffer.Count; i++)
        {
            OneWayBoxPlatform platform = ignoredBuffer[i];
            if (platform == null)
            {
                ignoredPlatforms.Remove(platform);
                continue;
            }

            bool isNearby = nearbyPlatforms.Contains(platform);
            bool hasHorizontalOverlap = isNearby && platform.HasHorizontalSupportOverlap(playerBounds);

            if (isNearby && hasHorizontalOverlap)
                continue;

            SetIgnored(platform, false);
        }
    }

    private void RestoreAllIgnoredCollisions()
    {
        if (ignoredPlatforms.Count == 0)
            return;

        ignoredBuffer.Clear();
        ignoredBuffer.AddRange(ignoredPlatforms);

        for (int i = 0; i < ignoredBuffer.Count; i++)
        {
            OneWayBoxPlatform platform = ignoredBuffer[i];
            if (platform != null)
                ApplyIgnoreCollision(platform, false);
        }

        ignoredPlatforms.Clear();
        ignoredBuffer.Clear();
    }

    private void SetIgnored(OneWayBoxPlatform platform, bool ignored)
    {
        if (platform == null || platform.Box == null || capsule == null)
            return;

        if (ignored)
        {
            if (!ignoredPlatforms.Add(platform))
                return;

            ApplyIgnoreCollision(platform, true);
            return;
        }

        if (!ignoredPlatforms.Remove(platform))
            return;

        ApplyIgnoreCollision(platform, false);
    }

    private void ApplyIgnoreCollision(OneWayBoxPlatform platform, bool ignored)
    {
        if (platform == null || platform.Box == null || capsule == null)
            return;

        Physics.IgnoreCollision(capsule, platform.Box, ignored);
    }

    private void CacheComponents()
    {
        if (rb == null)
            rb = GetComponent<Rigidbody>();

        if (capsule == null)
            capsule = GetComponent<CapsuleCollider>();
    }

    private void ClampSettings()
    {
        searchPaddingX = Mathf.Max(0f, searchPaddingX);
        searchPaddingY = Mathf.Max(0f, searchPaddingY);
        searchPaddingZ = Mathf.Max(0f, searchPaddingZ);
        maxUpwardSpeedToSolidify = Mathf.Max(0f, maxUpwardSpeedToSolidify);
        bottomYEpsilon = Mathf.Max(0f, bottomYEpsilon);
    }

    private void DrawRuntimeDebug()
    {
        if (!drawDebugPreview || capsule == null)
            return;

        Bounds playerBounds = capsule.bounds;
        Vector3 center = playerBounds.center;
        Vector3 halfExtents = new Vector3(
            playerBounds.extents.x + searchPaddingX,
            playerBounds.extents.y + searchPaddingY,
            playerBounds.extents.z + searchPaddingZ
        );

        DrawWireBox(center, halfExtents, Color.white);

        float playerBottomY = playerBounds.min.y;
        Vector3 bottomA = new Vector3(center.x - playerBounds.extents.x, playerBottomY, center.z);
        Vector3 bottomB = new Vector3(center.x + playerBounds.extents.x, playerBottomY, center.z);
        Debug.DrawLine(bottomA, bottomB, Color.magenta);
    }

    private void OnDrawGizmosSelected()
    {
        if (!drawDebugWhileSelected)
            return;

        CacheComponents();
        if (capsule == null)
            return;

        Bounds playerBounds = capsule.bounds;
        Vector3 center = playerBounds.center;
        Vector3 size = new Vector3(
            (playerBounds.extents.x + searchPaddingX) * 2f,
            (playerBounds.extents.y + searchPaddingY) * 2f,
            (playerBounds.extents.z + searchPaddingZ) * 2f
        );

        Gizmos.color = Color.white;
        Gizmos.DrawWireCube(center, size);

        Gizmos.color = Color.magenta;
        Gizmos.DrawLine(
            new Vector3(center.x - playerBounds.extents.x, playerBounds.min.y, center.z),
            new Vector3(center.x + playerBounds.extents.x, playerBounds.min.y, center.z)
        );
    }

    private static void DrawWireBox(Vector3 center, Vector3 halfExtents, Color color)
    {
        Vector3 p0 = center + new Vector3(-halfExtents.x, -halfExtents.y, -halfExtents.z);
        Vector3 p1 = center + new Vector3(halfExtents.x, -halfExtents.y, -halfExtents.z);
        Vector3 p2 = center + new Vector3(halfExtents.x, -halfExtents.y, halfExtents.z);
        Vector3 p3 = center + new Vector3(-halfExtents.x, -halfExtents.y, halfExtents.z);

        Vector3 p4 = center + new Vector3(-halfExtents.x, halfExtents.y, -halfExtents.z);
        Vector3 p5 = center + new Vector3(halfExtents.x, halfExtents.y, -halfExtents.z);
        Vector3 p6 = center + new Vector3(halfExtents.x, halfExtents.y, halfExtents.z);
        Vector3 p7 = center + new Vector3(-halfExtents.x, halfExtents.y, halfExtents.z);

        Debug.DrawLine(p0, p1, color);
        Debug.DrawLine(p1, p2, color);
        Debug.DrawLine(p2, p3, color);
        Debug.DrawLine(p3, p0, color);

        Debug.DrawLine(p4, p5, color);
        Debug.DrawLine(p5, p6, color);
        Debug.DrawLine(p6, p7, color);
        Debug.DrawLine(p7, p4, color);

        Debug.DrawLine(p0, p4, color);
        Debug.DrawLine(p1, p5, color);
        Debug.DrawLine(p2, p6, color);
        Debug.DrawLine(p3, p7, color);
    }
}
