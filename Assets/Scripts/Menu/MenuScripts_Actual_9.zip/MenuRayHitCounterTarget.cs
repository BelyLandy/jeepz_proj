using UnityEngine;

[DisallowMultipleComponent]
public sealed class MenuRayHitCounterTarget : MonoBehaviour
{
    [Header("Hit Count")]
    [SerializeField, Min(1)] private int requiredHits = 3;
    [SerializeField] private GameObject objectToHide;

    [Header("Disappear Mode")]
    [SerializeField] private bool destroyInsteadOfHide = false;

    [Header("Scene Transition On Threshold")]
    [SerializeField] private bool loadSceneOnThresholdReached = false;
    [SerializeField] private GameSceneId loadingTargetScene = GameSceneId.GameplayScene;
    [SerializeField, Min(0f)] private float sceneSwitchDelayAfterThreshold = 0.15f;

    private int currentHits;
    private bool thresholdReached;

    public int CurrentHits => currentHits;
    public int RequiredHits => requiredHits;
    public bool ThresholdReached => thresholdReached;

    private void OnValidate()
    {
        requiredHits = Mathf.Max(1, requiredHits);
        sceneSwitchDelayAfterThreshold = Mathf.Max(0f, sceneSwitchDelayAfterThreshold);
    }

    public void RegisterRayHit()
    {
        if (thresholdReached)
            return;

        currentHits++;
        if (currentHits < requiredHits)
            return;

        thresholdReached = true;

        GameObject targetObject = objectToHide != null ? objectToHide : gameObject;
        if (destroyInsteadOfHide)
            Destroy(targetObject);
        else
            targetObject.SetActive(false);

        if (!loadSceneOnThresholdReached)
            return;

        SceneLoadManager manager = SceneLoadManager.EnsureInstance();
        if (manager != null)
            manager.LoadSceneViaLoadingScene(loadingTargetScene, sceneSwitchDelayAfterThreshold);
    }
}
