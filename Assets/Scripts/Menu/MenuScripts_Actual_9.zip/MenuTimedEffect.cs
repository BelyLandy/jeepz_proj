using UnityEngine;

[DisallowMultipleComponent]
public sealed class MenuTimedEffect : MonoBehaviour
{
    [SerializeField, Min(0f)] private float lifeTime = 0.25f;

    private void OnEnable()
    {
        if (lifeTime <= 0f)
        {
            Destroy(gameObject);
            return;
        }

        Destroy(gameObject, lifeTime);
    }

    private void OnValidate()
    {
        lifeTime = Mathf.Max(0f, lifeTime);
    }
}
